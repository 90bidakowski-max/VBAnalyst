(function(){'use strict';
 const PATHS={expert:'/projektunterstuetzung/',team:'/expertenteams/',service:'/managed-services/',permanent:'/personalvermittlung/'};
 function modelHref(config,model){if(!PATHS[model])model='expert';const prefix=config.lang==='en'?'/en':'';const params=new URLSearchParams({modell:model,thema:config.subject,bereich:config.field,briefing:config.brief.slice(0,2400)});return prefix+'/kontakt/?'+params;}
 if(typeof module!=='undefined'&&module.exports)module.exports={modelHref,PATHS};
 if(typeof document==='undefined')return;
 document.querySelectorAll('[data-engagement-builder]').forEach(root=>{
  const config=JSON.parse(root.querySelector('[data-engagement-config]').textContent);const choices=[...root.querySelectorAll('[data-model-choice]')];
  const target=root.querySelector('[data-model-enquiry]'),info=root.querySelector('[data-model-info]'),status=root.querySelector('[data-model-status]'),en=config.lang==='en';
  function select(model){choices.forEach(choice=>{const active=choice.dataset.modelChoice===model;choice.classList.toggle('selected',active);choice.setAttribute('aria-pressed',String(active));});target.href=modelHref(config,model);info.href=(en?'/en':'')+PATHS[model];status.textContent=(en?'Selected model: ':'Gewähltes Modell: ')+config.models[model];const labels=en?{expert:'Discuss this project requirement',team:'Discuss the team and interfaces',service:'Check this managed service scope',permanent:'Define the hiring brief'}:{expert:'Diesen Projektbedarf klären',team:'Team und Schnittstellen besprechen',service:'Diesen Serviceumfang prüfen',permanent:'Suchprofil für die Stelle klären'};target.textContent=labels[model]+' ↗';}
  choices.forEach(choice=>{choice.setAttribute('role','button');choice.addEventListener('click',e=>{e.preventDefault();select(choice.dataset.modelChoice);});choice.addEventListener('keydown',e=>{if(e.key===' '){e.preventDefault();choice.click();}});});
  select(PATHS[config.initial]?config.initial:'expert');
 });
})();
