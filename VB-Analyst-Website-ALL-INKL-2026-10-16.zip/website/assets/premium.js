(function(){'use strict';
 function progressPercent(scroll,height,viewport){const range=Math.max(0,height-viewport);return range?Math.max(0,Math.min(100,Math.round(scroll/range*100))):0;}
 if(typeof module!=='undefined'&&module.exports)module.exports={progressPercent};
 if(typeof document==='undefined')return;
 const q=(s,r=document)=>r.querySelector(s),qa=(s,r=document)=>[...r.querySelectorAll(s)],en=document.documentElement.lang==='en',T=(a,b)=>en?b:a;
 const reduce=matchMedia('(prefers-reduced-motion: reduce)'),header=q('.premium-header'),bar=q('[data-reading-progress]'),sidebar=q('[data-conversion]'),panel=sidebar&&q('[data-conversion-panel]',sidebar),tab=sidebar&&q('[data-conversion-toggle]',sidebar);
 let ticking=false,blocked=false,autoShown=false,dismissed=false;
 function showPanel(open){if(!panel)return;panel.hidden=!open;tab.setAttribute('aria-expanded',String(open));sidebar.classList.toggle('is-open',open);}
 function update(){ticking=false;const value=progressPercent(window.scrollY,document.documentElement.scrollHeight,window.innerHeight);document.documentElement.style.setProperty('--read-progress',value+'%');if(bar)bar.setAttribute('aria-valuenow',String(value));
  document.documentElement.style.setProperty('--parallax-y',reduce.matches||window.innerWidth<900?'0px':Math.min(65,window.scrollY*.16)+'px');
  if(sidebar){sidebar.hidden=value<12||value>94||blocked;if(sidebar.hidden)showPanel(false);else if(!autoShown&&!dismissed&&value>=35&&window.innerWidth>=1900){autoShown=true;showPanel(true);}}
 }
 function schedule(){if(!ticking){ticking=true;requestAnimationFrame(update);}}
 window.addEventListener('scroll',schedule,{passive:true});window.addEventListener('resize',schedule);reduce.addEventListener('change',schedule);
 if(header){const syncHeight=()=>document.documentElement.style.setProperty('--header-height',header.getBoundingClientRect().height+'px');syncHeight();if('ResizeObserver' in window)new ResizeObserver(()=>{syncHeight();schedule();}).observe(header);}
 if('ResizeObserver' in window)new ResizeObserver(schedule).observe(document.body);
 if(sidebar){tab.addEventListener('click',()=>{dismissed=true;showPanel(panel.hidden);});q('[data-conversion-close]',sidebar).addEventListener('click',()=>{dismissed=true;showPanel(false);tab.focus();});sidebar.addEventListener('keydown',e=>{if(e.key==='Escape'){dismissed=true;showPanel(false);tab.focus();}});if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>{blocked=entries.some(e=>e.isIntersecting);schedule();},{rootMargin:'0px 0px 70px 0px'});const foot=q('.footer-focus');if(foot)observer.observe(foot);}}
 update();
 // Native details keep their semantics. Only their content height is animated.
 qa('details:not(.mobile-nav):not([data-mega])').forEach(details=>{
  const summary=q('summary',details);if(!summary)return;const body=document.createElement('div');body.className='details-body';[...details.childNodes].forEach(node=>{if(node!==summary)body.appendChild(node);});details.appendChild(body);let busy=false;
  summary.addEventListener('click',event=>{
   if(reduce.matches||typeof body.animate!=='function')return;event.preventDefault();if(busy)return;busy=true;
   const opening=!details.open;let from,to;
   if(opening){body.style.height='0px';details.open=true;from=0;to=body.scrollHeight;}else{from=body.getBoundingClientRect().height;to=0;}
   body.style.overflow='hidden';const animation=body.animate([{height:from+'px',opacity:opening?.25:1},{height:to+'px',opacity:opening?1:.25}],{duration:280,easing:'cubic-bezier(.22,.7,.2,1)',fill:'both'});
   animation.finished.then(()=>{if(!opening)details.open=false;body.style.height='';body.style.overflow='';animation.cancel();busy=false;schedule();}).catch(()=>{body.style.height='';body.style.overflow='';busy=false;});
  });
 });
 function revealHash(){if(!location.hash)return;let target;try{target=document.getElementById(decodeURIComponent(location.hash.slice(1)));}catch{return;}if(!target)return;let parent=target.closest('details');while(parent){parent.open=true;parent=parent.parentElement&&parent.parentElement.closest('details');}}
 window.addEventListener('hashchange',revealHash);revealHash();
 // Reading navigation follows the section in view without changing the URL.
 qa('.page-nav').forEach(nav=>{const links=qa('a[href^="#"]',nav),targets=links.map(a=>document.getElementById(a.hash.slice(1))).filter(Boolean);if(!targets.length||!('IntersectionObserver' in window))return;const observer=new IntersectionObserver(entries=>{const visible=entries.filter(e=>e.isIntersecting).sort((a,b)=>a.boundingClientRect.top-b.boundingClientRect.top)[0];if(!visible)return;links.forEach(a=>{if(a.hash==='#'+visible.target.id)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');});},{rootMargin:'-140px 0px -50% 0px'});targets.forEach(t=>observer.observe(t));});
 const form=q('[data-enquiry]');if(form&&!form.hasAttribute('data-server-form')){const status=q('[data-form-status-text]',form);function sync(){const stage=form.dataset.formStage||'1';if(status)status.textContent=stage==='prepared'?T('Entwurf vorbereitet. Sie versenden die E-Mail selbst.','Draft prepared. You send the email yourself.'):stage==='2'?T('Schritt 2: Ergänzen Sie Ihre Kontaktdaten.','Step 2: Add your contact details.'):T('Schritt 1: Beschreiben Sie Ihre Aufgabe.','Step 1: Describe your task.');}new MutationObserver(sync).observe(form,{attributes:true,attributeFilter:['data-form-stage']});sync();}
})();
