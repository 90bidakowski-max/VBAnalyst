/* Transparent, deterministic teaching models; no Power BI runtime or remote data. */
(function () {
'use strict';
const transactions = [];
for (let month=1;month<=6;month++) ['north','south','west'].forEach((region,r)=>['platform','service'].forEach((product,p)=>{
 const revenue=12000+month*2100+r*1700+(p===0?14000:0);
 const cost=Math.round(revenue*(p===0?.62:.81));
 transactions.push({id:`TX-${month}${r}${p}`,region,product,orderMonth:month,invoiceMonth:month+((month+r+p)%3===0?1:0),revenue,cost,plan:revenue+(month%2===0?-1800:2400)});
}));
const sum=(rows,key)=>rows.reduce((n,r)=>n+r[key],0);
function filterRows(s={}) {
 const role=s.dateRole==='invoice'?'invoiceMonth':'orderMonth';
 return transactions.filter(r=>(!s.region||s.region==='all'||s.relationship===false||r.region===s.region)&&(!s.product||s.product==='all'||r.product===s.product)&&r[role]>=1&&r[role]<=6&&(!s.period||s.period==='all'||(s.period==='q1'?r[role]<=3:r[role]>=4)));
}
function aggregate(rows){const revenue=sum(rows,'revenue'),cost=sum(rows,'cost'),plan=sum(rows,'plan');return {revenue,cost,plan,contribution:revenue-cost,margin:revenue?(revenue-cost)/revenue:null,variance:revenue-plan,count:rows.length};}
function dax(s={}) {
 const rows=filterRows(s),total=aggregate(rows);
 const groups=['platform','service'].map(product=>({product,...aggregate(rows.filter(r=>r.product===product))}));
 return {total,groups,weighted:total.margin,average:groups.reduce((n,g)=>n+g.margin,0)/groups.length};
}
const inputs=[
 {id:' A-01 ',region:'Nord',amount:'12.450,00'},
 {id:'A-01',region:'Nord',amount:'12.450,00'},
 {id:'B-02',region:'Süd',amount:'8.100,50'},
 {id:'C-03',region:'West',amount:'offen'},
 {id:'D-04',region:'Ost',amount:'4.800,00'},
 {id:'B-02',region:'Süd',amount:'8.900,50'}
];
function pipeline(s={normalize:true,dedupe:true,quarantine:true}) {
 const rows=inputs.map((r,index)=>({...r,index,id:s.normalize?r.id.trim():r.id,value:s.normalize&&/^\d{1,3}(\.\d{3})*,\d{2}$/.test(r.amount)?Number(r.amount.replaceAll('.','').replace(',','.')):null}));
 const conflicts=new Set();
 if(s.dedupe) rows.forEach(r=>{if(rows.some(x=>x.id===r.id&&(x.amount!==r.amount||x.region!==r.region)))conflicts.add(r.id);});
 const seen=new Set();
 rows.forEach(r=>{
  const invalid=r.value===null||!['Nord','Süd','West'].includes(r.region);
  if(conflicts.has(r.id))r.status='conflict';
  else if(s.dedupe&&seen.has(r.id))r.status='duplicate';
  else if(invalid)r.status=s.quarantine?'quarantine':'unresolved';
  else r.status='accepted';
  seen.add(r.id);
 });
 const accepted=rows.filter(r=>r.status==='accepted');
 return {rows,accepted,total:sum(accepted,'value'),blocked:rows.some(r=>r.status==='unresolved'),conflicts:rows.filter(r=>r.status==='conflict').length};
}
function performance(s={}) {
 const baseline=s.workload==='refresh'?[0,0,6200]:s.workload==='visual'?[900,4400,0]:[4800,600,0];
 const after=baseline.map((n,i)=>Math.round(n*([s.fixDax,s.fixVisual,s.fixSource][i]?[.38,.45,.42][i]:1)));
 const before=baseline.reduce((a,b)=>a+b,0),total=after.reduce((a,b)=>a+b,0);
 return {baseline,after,before,total,saving:1-total/before};
}
const engine={transactions,filterRows,aggregate,dax,inputs,pipeline,performance};
if(typeof module!=='undefined'&&module.exports)module.exports=engine;
if(typeof document==='undefined')return;
const en=document.documentElement.lang.startsWith('en');
const t=(de,eng)=>en?eng:de;
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>new Intl.NumberFormat(en?'en-GB':'de-DE',{style:'currency',currency:'EUR',maximumFractionDigits:0}).format(n);
const precise=n=>new Intl.NumberFormat(en?'en-GB':'de-DE',{style:'currency',currency:'EUR',minimumFractionDigits:2}).format(n);
const pct=n=>n===null?'—':new Intl.NumberFormat(en?'en-GB':'de-DE',{style:'percent',maximumFractionDigits:1}).format(n);
const months=en?['Jan','Feb','Mar','Apr','May','Jun','Jul']:['Jan','Feb','Mär','Apr','Mai','Jun','Jul'];
const region=r=>({north:t('Nord','North'),south:t('Süd','South'),west:'West',all:t('Alle Regionen','All regions')})[r];
const product=p=>p==='platform'?t('Plattform','Platform'):'Service';
const kpi=(label,value,note='')=>`<div class="studio-kpi"><span>${label}</span><strong>${value}</strong><small>${note}</small></div>`;
const note=(text,warning=false)=>`<p class="studio-note${warning?' studio-warning':''}">${text}</p>`;
const table=(heads,rows,caption)=>`<div class="studio-table-wrap" tabindex="0" role="region" aria-label="${esc(caption)}"><table><caption>${caption}</caption><thead><tr>${heads.map(h=>`<th scope="col">${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map((v,i)=>i?`<td>${v}</td>`:`<th scope="row">${v}</th>`).join('')}</tr>`).join('')}</tbody></table></div>`;
function detail(rows){return table([t('Beleg','Record'),t('Region','Region'),t('Produkt','Product'),t('Auftrag / Rechnung','Order / invoice'),t('Umsatz','Revenue'),t('Kosten','Cost')],rows.map(r=>[r.id,region(r.region),product(r.product),`${months[r.orderMonth-1]} / ${months[r.invoiceMonth-1]}`,money(r.revenue),money(r.cost)]),t('Fiktive Geschäftsvorfälle · alle Beträge in EUR','Invented transactions · all amounts in EUR'));}
function report(s,selected) {
 const rows=filterRows(s),a=aggregate(rows),metric=s.metric==='contribution'?'contribution':'revenue';
 const list=[1,2,3,4,5,6].filter(m=>s.period==='all'||(s.period==='q1'?m<=3:m>=4));
 const values=list.map(m=>({month:m,...aggregate(rows.filter(r=>r.orderMonth===m))}));
 const max=Math.max(...values.map(a=>Math.max(a[metric],metric==='revenue'?a.plan:0)),1);
 let html=`<div class="studio-kpis">${kpi(t('Umsatz','Revenue'),money(a.revenue),`${a.count} ${t('Datensätze','records')}`)}${kpi(t('Ergebnisbeitrag','Contribution'),money(a.contribution),`${pct(a.margin)} ${t('Marge','margin')}`)}${kpi(t('Planabweichung Umsatz','Revenue vs plan'),money(a.variance),`${t('Plan','Plan')}: ${money(a.plan)}`)}</div>`;
 html+=`<div class="studio-chart-head"><h4>${metric==='revenue'?t('Umsatz im Verlauf','Revenue over time'):t('Ergebnisbeitrag im Verlauf','Contribution over time')}</h4><span><i></i> ${t('Ist','Actual')}${metric==='revenue'?` · <b></b> ${t('Plan','Plan')}`:''}</span></div><div class="studio-bars">`;
 html+=values.map(v=>`<button type="button" class="studio-month" data-month="${v.month}" aria-label="${months[v.month-1]}: ${money(v[metric])}" aria-pressed="${selected===v.month}"><span class="studio-bar-value" aria-hidden="true">${new Intl.NumberFormat(en?'en-GB':'de-DE',{maximumFractionDigits:1}).format(v[metric]/1000)}<small>k€</small></span><span class="studio-bar-track"><span style="height:${v[metric]/max*100}%"></span>${metric==='revenue'?`<i style="bottom:${v.plan/max*100}%"></i>`:''}</span><strong>${months[v.month-1]}</strong></button>`).join('')+'</div>';
 const focused=selected?rows.filter(r=>r.orderMonth===selected):rows;
 html+=`<div class="studio-drill"><h4>${selected?months[selected-1]+' · ':''}${t('Daten hinter dem Diagramm','Data behind the chart')}</h4>${selected?`<button type="button" data-month="0">${t('Alle Monate zeigen','Show every month')}</button>`:''}<details ${selected?'open':''}><summary>${focused.length} ${t('Datensätze prüfen','records to inspect')}</summary>${detail(focused)}</details></div>`;
 html+=note(t('Die Planabweichung bezieht sich immer auf den Umsatz. Der Ergebnisbeitrag ist Umsatz minus Kosten. Eine Monatsauswahl grenzt nur die Detailtabelle ein.','Plan variance always relates to revenue. Contribution is revenue minus cost. Selecting a month narrows only the detail table.'));
 return html;
}
function renderDax(s) {
 const d=dax(s),formula=s.formula;
 const result=formula==='average'?d.average:formula==='share'?1:d.weighted;
 const code=formula==='average'?'Average product margin :=\nAVERAGEX(VALUES(Product[Name]), [Margin %])':formula==='share'?'Revenue share :=\nDIVIDE([Revenue],\n  CALCULATE([Revenue], REMOVEFILTERS(Product)))':'Margin % :=\nDIVIDE([Contribution], [Revenue])';
 let html=`<div class="studio-kpis">${kpi(t('Ergebnis der Totalzeile','Total row result'),pct(result),formula==='share'?t('Summe der Produktanteile','Sum of product shares'):formula==='average'?t('Jedes Produkt zählt gleich','Each product has equal weight'):t('Nach Umsatz gewichtet','Weighted by revenue'))}${kpi(t('Gewichtete Gesamtmarge','Weighted overall margin'),pct(d.weighted))}${kpi(t('Abweichung Durchschnitt','Average difference'),`${((d.average-d.weighted)*100).toFixed(2)} ${t('Prozentpunkte','percentage points')}`)}</div>`;
 html+=table([t('Produkt','Product'),t('Umsatz','Revenue'),t('Beitrag','Contribution'),t('Marge','Margin'),t('Umsatzanteil','Revenue share')],d.groups.map(g=>[product(g.product),money(g.revenue),money(g.contribution),pct(g.margin),pct(g.revenue/d.total.revenue)]),t('Kontrollwerte im aktuellen Filterkontext','Control values in the current filter context'));
 html+=`<pre class="studio-code"><code>${esc(code)}</code></pre>`;
 html+=note(formula==='average'?t('Der Durchschnitt der zwei Produktmargen beantwortet eine andere Frage als die Gesamtmarge. Unterschiedliche Umsätze erhalten hier dasselbe Gewicht.','Averaging the two product margins answers a different question from overall margin. Different revenues receive equal weight here.'):formula==='share'?t('Der Nenner entfernt nur den Produktfilter. Region und Zeitraum bleiben erhalten. Die beiden Anteile ergeben zusammen 100 %.','The denominator removes only the product filter. Region and period remain in context. Both shares add up to 100%.'):t(`Kontrollrechnung: ${money(d.total.contribution)} Beitrag ÷ ${money(d.total.revenue)} Umsatz. Die Totalzeile berechnet den Quotienten neu.`,`Control calculation: ${money(d.total.contribution)} contribution ÷ ${money(d.total.revenue)} revenue. The total row recalculates the ratio.`));
 return html;
}
function renderModel(s) {
 const rows=filterRows(s),a=aggregate(rows),connected=aggregate(filterRows({...s,relationship:true}));
 return `<div class="studio-model"><div><small>DIMENSION</small><strong>${t('Region','Region')}</strong><span>${region(s.region)}</span></div><span class="studio-link${s.relationship?'':' studio-disconnected'}">1 ${s.relationship?'→':'×'} *</span><div><small>FACT</small><strong>${t('Transaktionen','Transactions')}</strong><span>${a.count} ${t('Zeilen','rows')}</span></div><span class="studio-link">* ← 1</span><div><small>DIMENSION</small><strong>${t('Datum','Date')}</strong><span>${s.dateRole==='invoice'?t('Rechnung','Invoice'):t('Auftrag','Order')}</span></div></div><div class="studio-kpis">${kpi(t('Gefilterter Umsatz','Filtered revenue'),money(a.revenue))}${kpi(t('Mit aktiver Regionsbeziehung','With active region relationship'),money(connected.revenue))}${kpi(t('Differenz durch Beziehung','Relationship difference'),money(a.revenue-connected.revenue))}</div>`+note(s.relationship?t('Der Regionsfilter erreicht die Faktentabelle über die aktive 1:n-Beziehung.','The region filter reaches the fact table through the active one-to-many relationship.'):t('Beziehung deaktiviert: Die Auswahl in der Regionstabelle filtert die Transaktionen nicht mehr. Wählen Sie eine einzelne Region, um die Abweichung zu sehen.','Relationship disabled: selecting a dimension region no longer filters transactions. Choose a single region to see the difference.'),!s.relationship)+note(t('Der Zeitraum umfasst Januar bis Juni. Bei Rechnungsdatum fallen im Juli fakturierte Aufträge aus diesem Fenster; es werden keine fehlenden Monate erfunden.','The period covers January to June. Using invoice date excludes orders invoiced in July from this window; missing months are not invented.'))+`<details><summary>${t('Filterergebnis auf Zeilenebene prüfen','Inspect the filter result at row level')}</summary>${detail(rows)}</details>`;
}
function renderData(s) {
 const p=pipeline(s),names={accepted:t('Übernommen','Accepted'),duplicate:t('Exakte Dublette','Exact duplicate'),conflict:t('ID-Konflikt · prüfen','ID conflict · review'),quarantine:t('Fehlerliste','Exception list'),unresolved:t('Ungültig · blockiert','Invalid · blocked')};
 let html=`<div class="studio-kpis">${kpi(t('Eingang','Input'),'6',t('Originalzeilen bleiben sichtbar','Original records stay visible'))}${kpi(t('Übernommen','Accepted'),String(p.accepted.length),`${p.conflicts} ${t('Zeilen mit ID-Konflikt','rows with ID conflicts')}`)}${kpi(t('Gültige Teilsumme','Valid subtotal'),precise(p.total),p.blocked?t('Veröffentlichung blockiert','Publication blocked'):t('Nur übernommene Zeilen','Accepted rows only'))}</div>`;
 html+=table([t('Zeile / Roh-ID','Row / raw ID'),t('Ergebnis-ID','Output ID'),t('Region','Region'),t('Rohwert','Raw amount'),t('Status','Status')],p.rows.map(r=>[`${r.index+1} · <code>${esc(inputs[r.index].id).replaceAll(' ','·')}</code>`,esc(r.id),esc(r.region),esc(r.amount),`<span class="studio-status ${r.status==='accepted'?'is-ok':''}">${names[r.status]}</span>`]),t('Verarbeitungsprotokoll für alle Eingangszeilen','Processing audit for every input row'));
 html+=note(t('Regel: Deutsche Dezimalwerte werden explizit geparst. Identische IDs mit identischem Inhalt werden einmal übernommen. Unterschiedliche Werte unter derselben ID gehen vollständig zur Klärung. „Ost“ ist in der Regionsdimension nicht enthalten.','Rule: German decimal amounts are parsed explicitly. Identical IDs with identical content are accepted once. Conflicting values under the same ID are all held for review. “Ost” is absent from the region dimension.'));
 if(!s.normalize)html+=note(t('Ohne Typisierung ist kein Betrag als Zahl verfügbar. Die Teilsumme ist deshalb kein Geschäftsergebnis.','Without type conversion, no amount is available as a number. The subtotal is therefore not a business result.'),true);
 if(!s.dedupe)html+=note(t('Die ID-Prüfung ist ausgeschaltet: Dubletten und Konflikte können die Summe erhöhen.','ID checking is disabled: duplicates and conflicts can inflate the subtotal.'),true);
 if(p.blocked)html+=note(t('Ungültige Zeilen verbleiben im Ergebnis. Die Pipeline blockiert die Freigabe, statt die Fehler stillschweigend als Null zu behandeln.','Invalid rows remain in the result. The pipeline blocks acceptance instead of silently treating errors as zero.'),true);
 return html;
}
function renderPerformance(s) {
 const p=performance(s),names=[t('Kennzahlenberechnung','Measure evaluation'),t('Darstellung','Rendering'),t('Datenzufuhr / Refresh','Ingestion / refresh')];
 return `<div class="studio-kpis">${kpi(t('Ausgangswert','Baseline'),(p.before/1000).toFixed(2)+' s')}${kpi(t('Nach Maßnahme','After change'),(p.total/1000).toFixed(2)+' s')}${kpi(t('Modellierte Reduktion','Modelled reduction'),pct(p.saving))}</div>`+table([t('Komponente','Component'),t('Vorher','Before'),t('Nachher','After')],names.map((n,i)=>[n,`${p.baseline[i]} ms`,`<span class="studio-timing" style="--share:${Math.max(1,p.after[i]/6200*100)}%">${p.after[i]} ms</span>`]),t('Synthetisches, sequenzielles Zeitmodell','Synthetic sequential timing model'))+note(t('Diese Werte sind frei gewählte Lehrbeispiele, keine gemessenen Benchmarks oder Leistungszusagen. Berichtsabfrage und Datenaktualisierung sind getrennte Abläufe: Eine schnellere Datenzufuhr verändert hier keine Import-Berichtsabfrage. Echte Messungen müssen Cache, Parallelität und denselben Testzustand berücksichtigen.','These are invented teaching values, not measured benchmarks or performance promises. Report queries and data refresh are separate operations: faster ingestion does not change an Import report query here. Real measurements must account for cache, concurrency and equivalent test conditions.'));
}
function renderReadiness(s) {
 const missing=[!s.definitions&&t('Kennzahlendefinitionen bestätigen','Approve metric definitions'),!s.access&&t('Quellenzugriff einrichten','Arrange source access'),!s.owner&&t('Abnahmeverantwortlichen benennen','Assign an acceptance owner')].filter(Boolean);
 const packs={report:[t('Berichtsseite mit abgestimmtem Analysepfad','Report page with an agreed analysis path'),t('Kennzahlen gegen Kontrollwerte abgleichen; Filter und Detailnavigation prüfen.','Reconcile metrics with control values; check filtering and detail navigation.')],rescue:[t('Reproduzierbarer Fehlerfall mit dokumentierter Korrektur','Reproducible issue with a documented correction'),t('Ausgangsfehler erneut testen; unveränderte Kennzahlen und Refresh nachweisen.','Retest the original issue; verify unchanged metrics and refresh behaviour.')],model:[t('Semantisches Modell mit dokumentiertem Grain und Beziehungen','Semantic model with documented grain and relationships'),t('Schlüssel, Mehrfachfakten und Datumsrollen anhand definierter Prüffälle abnehmen.','Accept keys, multiple facts and date roles using defined test cases.')]};
 const [deliverable,criteria]=packs[s.package];
 return `<div class="studio-kpis">${kpi(t('Voraussetzungen erfüllt','Prerequisites met'),`${3-missing.length} / 3`)}${kpi(t('Startstatus','Readiness'),missing.length?t('Klärung offen','Needs review'):t('Abstimmbar','Ready to agree'))}</div><div class="studio-scope"><div><h4>${t('Liefergegenstand','Deliverable')}</h4><p>${deliverable}</p><h4>${t('Abnahme','Acceptance')}</h4><p>${criteria}</p></div><div><h4>${t('Nächste Schritte','Next steps')}</h4><ul>${(missing.length?missing:[t('Umfang, Termin und Übergabe gemeinsam freigeben.','Agree scope, timeline and handover together.')]).map(m=>`<li>${m}</li>`).join('')}</ul></div></div>`+note(t('Die Auswahl ist eine Planungshilfe. Sie übermittelt keine Daten und reserviert keine Kapazität. Berechtigungen, Lizenzen und konkrete Zusagen werden im Projekt geklärt.','This is a planning aid. It transmits no data and reserves no capacity. Permissions, licensing and commitments are established in the project.'));
}
document.querySelectorAll('[data-studio]').forEach(root=>{
 const controls=[...root.querySelectorAll('[data-control]')],output=root.querySelector('[data-studio-output]');
 const defaults=controls.map(c=>c.type==='checkbox'?c.checked:c.value);let selected=0;
 const state=()=>Object.fromEntries(controls.map(c=>[c.dataset.control,c.type==='checkbox'?c.checked:c.value]));
 function render(){const s=state(),kind=root.dataset.studio;root.querySelector('[data-studio-status]').textContent=t('Berechnung aktualisiert.','Calculation updated.');output.innerHTML=kind==='report'?report(s,selected):kind==='dax'?renderDax(s):kind==='model'?renderModel(s):kind==='data'?renderData(s):kind==='performance'?renderPerformance(s):renderReadiness(s);}
 root.addEventListener('change',e=>{if(e.target.matches('[data-control]')){selected=0;render();}});
 root.addEventListener('click',e=>{
  const month=e.target.closest('[data-month]');if(month){selected=Number(month.dataset.month);render();const target=root.querySelector(`[data-month="${selected}"]`);if(target)target.focus();}
  if(e.target.closest('[data-studio-reset]')){controls.forEach((c,i)=>{if(c.type==='checkbox')c.checked=defaults[i];else c.value=defaults[i];});selected=0;render();}
 });
 render();
});
})();
