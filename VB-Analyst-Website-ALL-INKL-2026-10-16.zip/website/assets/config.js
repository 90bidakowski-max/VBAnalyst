window.VBConfig=Object.freeze({contactPath:'/api/contact.php'});
