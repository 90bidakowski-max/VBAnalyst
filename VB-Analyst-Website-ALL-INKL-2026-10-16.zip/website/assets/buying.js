(function(){'use strict';
 const en=document.documentElement.lang==='en',T=(de,eng)=>en?eng:de;
 document.querySelectorAll('[data-assignment-builder]').forEach(root=>{
  const boxes=[...root.querySelectorAll('[data-assignment-task]')],skills=[...root.querySelectorAll('[data-assignment-skill]')];
  const model=root.querySelector('[data-assignment-model]'),start=root.querySelector('[data-assignment-start]'),location=root.querySelector('[data-assignment-location]'),note=root.querySelector('[data-assignment-note]');
  const summary=root.querySelector('[data-assignment-summary]'),link=root.querySelector('[data-assignment-enquiry]'),framework=root.querySelector('[data-assignment-framework]');
  const context=[...root.querySelectorAll('[data-assignment-context]')],modelNote=root.querySelector('[data-assignment-model-note]');
  const label=select=>select.selectedOptions[0].textContent;
  function update(render=true){
   const scoped=context.filter(x=>x.value).map(x=>x.dataset.contextLabel+' '+label(x));
   if(modelNote)modelNote.textContent=model.value==='service'?modelNote.dataset.modelService:model.value==='permanent'?T('Für eine Festbesetzung klären wir Aufgaben, Erfahrung und Einbindung in Ihre Organisation.','For permanent recruitment, we clarify responsibilities, experience and organisational fit.'):model.value==='team'?T('Für ein Expertenteam klären wir ergänzende Kompetenzen, Schnittstellen und die gemeinsame Steuerung.','For an expert team, we clarify complementary skills, interfaces and coordination.'):model.value==='open'?T('Wir ordnen mit Ihnen ein, ob Einzelunterstützung, Festbesetzung, Team oder betreuter Ablauf zu Ihrem Bedarf passt.','We help establish whether a specialist, permanent hire, team or managed workflow fits your needs.'):modelNote.dataset.modelExpert;
   const selected=boxes.filter(b=>b.checked).map(b=>b.value),required=skills.filter(b=>b.checked).map(b=>b.value);
   if(render){
    summary.replaceChildren();
    const p=document.createElement('p');p.textContent=selected.length?T('Ausgewählte Aufgaben: ','Selected tasks: ')+selected.length:T('Noch keine Aufgaben ausgewählt. Sie können Ihren Bedarf auch frei beschreiben.','No tasks selected. You can also describe your need in your own words.');summary.append(p);
    if(selected.length){const ul=document.createElement('ul');selected.forEach(v=>{const li=document.createElement('li');li.textContent=v;ul.append(li);});summary.append(ul);}
    if(required.length){const p=document.createElement('p');p.textContent=T('Benötigte Kenntnisse: ','Required skills: ')+required.join(', ');summary.append(p);}
    if(framework){framework.replaceChildren();[[T('Zusammenarbeit: ','Engagement: '),model],[T('Start: ','Start: '),start],[T('Einsatz: ','Arrangement: '),location]].forEach(([title,select])=>{if(!select)return;const p=document.createElement('p');p.textContent=title+label(select);framework.append(p);});scoped.forEach(value=>{const p=document.createElement('p');p.textContent=value;framework.append(p);});}
   }
   const brief=[T('Gesuchte Expertise: ','Requested expertise: ')+root.dataset.role,...selected.map(v=>'• '+v)];
   if(required.length)brief.push(T('Benötigte Kenntnisse: ','Required skills: ')+required.join(', '));
   brief.push(T('Zusammenarbeit: ','Engagement: ')+label(model),T('Gewünschter Start: ','Preferred start: ')+label(start));
   if(location)brief.push(T('Einsatzort: ','Work arrangement: ')+label(location));
   brief.push(...scoped);
   if(note&&note.value.trim())brief.push(T('Ergänzung: ','Additional context: ')+note.value.trim());
   link.href=(en?'/en':'')+'/kontakt/?'+new URLSearchParams({bereich:root.dataset.field,modell:model.value,zeitpunkt:start.value,thema:root.dataset.role,briefing:brief.join('\n'),...(location?{arbeitsort:location.value}:{})});
  }
  [...boxes,...skills,...context,model,start,location].filter(Boolean).forEach(e=>e.addEventListener('change',()=>update()));
  if(note)note.addEventListener('input',()=>update(false));
  root.querySelector('[data-assignment-reset]')?.addEventListener('click',()=>{[...boxes,...skills].forEach(b=>b.checked=false);[model,start,location,...context].filter(Boolean).forEach(s=>s.selectedIndex=0);if(note)note.value='';update();});
  update();
 });
 // Native details remain fully functional without JS. Animate only their content.
 if(!matchMedia('(prefers-reduced-motion: reduce)').matches){document.querySelectorAll('.buying-detail').forEach(d=>d.addEventListener('toggle',()=>{if(d.open){const body=d.querySelector('.buying-detail-body');if(body&&body.animate)body.animate([{opacity:.25,transform:'translateY(-4px)'},{opacity:1,transform:'translateY(0)'}],{duration:220,easing:'ease-out'});}}));}
})();
