(function(){'use strict';
 const form=document.querySelector('[data-server-form]');if(!form)return;
 const en=document.documentElement.lang==='en',T=(de,eng)=>en?eng:de;
 const q=s=>form.querySelector(s),first=q('[data-form-step="1"]'),second=q('[data-form-step="2"]'),next=q('[data-next]'),back=q('[data-back]'),submit=q('[type="submit"]'),error=q('[data-submit-error]'),status=q('[data-form-status-text]'),progress=q('[data-form-progress]'),id=q('[name="request_id"]');
 let busy=false,lastPayload=null,stage=1;
 function newId(){if(window.crypto&&typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();if(window.crypto&&window.crypto.getRandomValues){const b=new Uint8Array(16);window.crypto.getRandomValues(b);b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const h=Array.from(b,v=>v.toString(16).padStart(2,'0')).join('');return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);}return '';}
 if(!id.value)id.value=newId();
 function show(n,focus){stage=n;first.hidden=n!==1;second.hidden=n!==2;first.disabled=false;second.disabled=false;form.dataset.formStage=String(n);progress.textContent=n+' / 2';status.textContent=n===1?T('Schritt 1: Beschreiben Sie Ihre Aufgabe.','Step 1: Describe your task.'):T('Schritt 2: Ergänzen Sie Ihre Kontaktdaten und senden Sie die Anfrage.','Step 2: Add your contact details and send your enquiry.');if(focus)(n===1?first:second).querySelector('input,select,textarea').focus();}
 function valid(area,n){for(const control of area.querySelectorAll('input,select,textarea'))if(!control.checkValidity()){show(n,false);control.reportValidity();return false;}return true;}
 function fail(message){error.textContent=message;error.hidden=false;error.focus();}
 function success(reference){ window.location.assign(en?'/en/danke/':'/danke/'); }
 next.addEventListener('click',()=>{if(!busy&&valid(first,1))show(2,true);});back.addEventListener('click',()=>{if(!busy)show(1,true);});
 form.addEventListener('submit',async event=>{
  event.preventDefault();if(busy)return;
  if(!valid(first,1))return;
  if(stage===1){show(2,true);return;}
  if(!valid(second,2))return;
  const data=Object.fromEntries(new FormData(form).entries()),fingerprint=JSON.stringify(Object.fromEntries(Object.entries(data).filter(([k])=>k!=='request_id')));
  if(lastPayload!==null&&lastPayload!==fingerprint){id.value=newId();data.request_id=id.value;}lastPayload=fingerprint;
  busy=true;error.hidden=true;form.setAttribute('aria-busy','true');first.disabled=second.disabled=true;submit.disabled=next.disabled=back.disabled=true;
  const buttonText=submit.textContent;submit.textContent=T('Wird gesendet …','Sending …');status.textContent=T('Ihre Anfrage wird sicher übermittelt.','Your enquiry is being submitted securely.');
  const controller=typeof AbortController==='function'?new AbortController():null,timer=controller?setTimeout(()=>controller.abort(),25000):null;
  try{
   const response=await fetch((window.VBConfig&&window.VBConfig.contactPath)||'/api/contact.php',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},credentials:'same-origin',body:JSON.stringify(data),signal:controller?controller.signal:undefined});
   let result;try{result=await response.json();}catch{throw new Error(T('Der Eingang Ihrer Anfrage wurde nicht bestätigt. Bitte versuchen Sie es erneut oder schreiben Sie an info@vb-analyst.de.','Receipt of your enquiry was not confirmed. Please try again or email info@vb-analyst.de.'));}
   if(!response.ok||result.saved!==true||!/^([a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12})$/i.test(result.reference||'')){
    if(response.status===409){id.value=newId();lastPayload=null;}
    throw new Error(typeof result.error==='string'?result.error:T('Eingang nicht bestätigt. Bitte erneut versuchen.','Receipt was not confirmed. Please try again.'));
   }
   success(result.reference);
  }catch(e){
   fail(e.name==='AbortError'||e instanceof TypeError?T('Die Verbindung wurde unterbrochen. Ihre Eingaben bleiben erhalten. Bitte erneut senden; identische Wiederholungen werden nur einmal gespeichert.','The connection was interrupted. Your entries are preserved. Please submit again; identical retries are only saved once.'):e.message);
  }finally{
   if(timer)clearTimeout(timer);busy=false;form.removeAttribute('aria-busy');first.disabled=second.disabled=false;submit.disabled=next.disabled=back.disabled=false;submit.textContent=buttonText;if(form.isConnected)status.textContent=T('Schritt 2: Prüfen Sie Ihre Angaben und senden Sie erneut.','Step 2: Check your details and submit again.');
  }
 });
 // Enhance only after all handlers exist. Native POST remains available without JS.
 form.noValidate=true;next.hidden=back.hidden=false;
 if(form.dataset.serverError==='true'){const firstInvalid=[...first.querySelectorAll('input,select,textarea')].some(c=>!c.checkValidity());show(firstInvalid?1:2,false);}else show(1,false);
})();
