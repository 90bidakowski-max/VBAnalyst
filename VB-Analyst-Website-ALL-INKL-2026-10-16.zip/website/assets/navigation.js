(function(){'use strict';
 const KEYS=['vergleich','q','bereich','typ','ziel','phase','taetigkeit','tool','leistung','ansicht','sortierung','seite','auswahl','modell','thema','briefing','rollenvergleich','vergleichsansicht','nur-unterschiede','kompass-aufgabe','kompass-tool'];
 function languageTarget(href,search,hash){const url=new URL(href,'https://vb-analyst.de');const params=new URLSearchParams(search);url.search='';KEYS.forEach(k=>{if(params.has(k))url.searchParams.set(k,params.get(k).slice(0,k==='briefing'?2400:800));});return url.pathname+url.search+(hash||'');}
 function bindMenus(menus,doc,media){
  function sync(menu){const summary=menu.querySelector('summary');summary.setAttribute('aria-expanded',String(menu.open));}
  function close(menu,focus=false){menu.open=false;sync(menu);if(focus)menu.querySelector('summary').focus();}
  menus.forEach(menu=>{
   const summary=menu.querySelector('summary');sync(menu);
   // Native summary activation works identically with mouse, touch, Enter and Space.
   menu.addEventListener('toggle',()=>{if(menu.open)menus.forEach(other=>{if(other!==menu)close(other);});sync(menu);});
   menu.addEventListener('keydown',e=>{if(e.key==='Escape'&&menu.open){e.preventDefault();close(menu,true);}if(e.key==='ArrowDown'&&e.target===summary){e.preventDefault();menu.open=true;sync(menu);menus.forEach(other=>{if(other!==menu)close(other);});const first=menu.querySelector('a[href]');if(first)first.focus();}});
   menu.addEventListener('focusout',e=>{if(e.relatedTarget&&!menu.contains(e.relatedTarget))close(menu);});
   menu.addEventListener('click',e=>{if(e.target.closest('a[href]'))close(menu);});
  });
  doc.addEventListener('click',e=>menus.forEach(menu=>{if(!menu.contains(e.target))close(menu);}));
  if(media&&media.addEventListener)media.addEventListener('change',()=>menus.forEach(menu=>close(menu)));
  return {close};
 }
 if(typeof module!=='undefined'&&module.exports)module.exports={languageTarget,bindMenus};
 if(typeof document==='undefined')return;
 bindMenus([...document.querySelectorAll('.premium-header details')],document,matchMedia('(max-width:1380px)'));
 const language=document.querySelector('[data-language-switch]');
 function updateLanguage(){if(language)language.href=languageTarget(language.getAttribute('href'),location.search,location.hash);}
 updateLanguage();window.addEventListener('popstate',updateLanguage);window.addEventListener('hashchange',updateLanguage);
 // Search/comparison state changes through replaceState are read at activation time.
 if(language)language.addEventListener('click',updateLanguage);
})();
