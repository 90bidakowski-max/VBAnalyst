<?php
declare(strict_types=1);
$GLOBALS['VB_PAGE']='/en/kontakt/';
require dirname(__DIR__,2).'/api/page.php';
