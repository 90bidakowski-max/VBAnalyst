<?php
$GLOBALS['VB_LANGUAGE']='en';
require dirname(__DIR__,2).'/api/thanks.php';
