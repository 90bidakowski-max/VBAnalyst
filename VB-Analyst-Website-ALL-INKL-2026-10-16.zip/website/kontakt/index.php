<?php
declare(strict_types=1);
$GLOBALS['VB_PAGE']='/kontakt/';
require dirname(__DIR__,1).'/api/page.php';
