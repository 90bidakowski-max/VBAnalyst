<?php
declare(strict_types=1);
function render_contact(array $values, ?array $result=null, int $status=200): never {
    $page=$GLOBALS['VB_INLINE_PAGE']??$GLOBALS['VB_PAGE']??'';
    if(!in_array($page,['/kontakt/','/en/kontakt/'],true)) {http_response_code(404);exit;}
    $en=str_starts_with($page,'/en/');
    $root=realpath($_SERVER['DOCUMENT_ROOT']??'');
    $source=file_get_contents($root.$page.'index.html');
    if($source===false) {http_response_code(503);exit('Contact page unavailable.');}
    $doc=new DOMDocument('1.0','UTF-8');
    libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="UTF-8">'.$source,LIBXML_NONET);
    foreach(iterator_to_array($doc->childNodes) as $node) if($node->nodeType===XML_PI_NODE) $doc->removeChild($node);
    libxml_clear_errors();
    $xp=new DOMXPath($doc);$form=$xp->query('//form[@id="anfrage"]')->item(0);
    if(!$form) {http_response_code(503);exit('Contact form unavailable.');}
    $text=function(DOMNode $parent,string $tag,string $value,array $attrs=[]) use($doc): DOMElement {
        $node=$doc->createElement($tag);$node->appendChild($doc->createTextNode($value));
        foreach($attrs as $k=>$v) $node->setAttribute($k,$v);
        $parent->appendChild($node);return $node;
    };
    if(($result['saved']??false)===true) {
        $done=$doc->createElement('section');
        foreach(['id'=>'anfrage','class'=>'form form-success','role'=>'status','tabindex'=>'-1'] as $k=>$v) $done->setAttribute($k,$v);
        $text($done,'span',$en?'Enquiry received':'Anfrage eingegangen',['class'=>'eyebrow']);
        $text($done,'h2',$en?'Thank you. Your enquiry has been received.':'Vielen Dank. Ihre Anfrage ist eingegangen.');
        $text($done,'p',$en?'VB Analyst will review your requirements and contact you using the details provided.':'VB Analyst prüft Ihren Bedarf und meldet sich über Ihre angegebenen Kontaktdaten.');
        $text($done,'p',($en?'Your reference: ':'Ihre Referenz: ').$result['reference'],['class'=>'request-reference']);
        $text($done,'a',$en?'Back to the homepage':'Zur Startseite',['href'=>$en?'/en/':'/','class'=>'button coral']);
        $form->parentNode->replaceChild($done,$form);
    } else {
        $form->setAttribute('data-server-restored','true');
        $values['language']=$en?'en':'de';
        if(!isset($values['request_id']) || !preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/iD',(string)$values['request_id']) || $status===409) $values['request_id']=request_uuid();
        foreach($xp->query('.//input[@name]|.//textarea[@name]|.//select[@name]',$form) as $node) {
            $name=$node->getAttribute('name');$value=$values[$name]??null;
            if($value===null || !is_string($value))continue;
            $value=clean($value,$name==='task'?4000:($name==='email'?250:200));
            if($node->tagName==='textarea') {
                while($node->firstChild)$node->removeChild($node->firstChild);
                $node->appendChild($doc->createTextNode($value));
            } elseif($node->tagName==='select') {
                foreach($node->getElementsByTagName('option') as $opt){$opt->removeAttribute('selected');if($opt->getAttribute('value')===$value)$opt->setAttribute('selected','selected');}
            } elseif($node->getAttribute('type')==='checkbox') {
                $node->removeAttribute('checked');if($value==='acknowledged')$node->setAttribute('checked','checked');
            } else $node->setAttribute('value',$value);
        }
        if(isset($result['error'])) {
            $form->setAttribute('data-server-error','true');
            $error=$xp->query('.//*[@data-submit-error]',$form)->item(0);
            $error->removeAttribute('hidden');$error->appendChild($doc->createTextNode($result['error']));
        }
    }
    http_response_code($status);
    header('Content-Type: text/html; charset=utf-8');header('Cache-Control: no-store');
    if(($_SERVER['REQUEST_METHOD']??'')==='GET') header_remove('X-Robots-Tag');
    echo $doc->saveHTML();exit;
}
function inline_form_result(array $result,int $status): never {
    render_contact($GLOBALS['VB_FORM_INPUT']??[], $result,$status);
}
