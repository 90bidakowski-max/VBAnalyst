<?php
declare(strict_types=1);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Robots-Tag: noindex, nofollow');
function respond(array $data, int $status = 200): never {
    if(isset($GLOBALS['VB_INLINE_PAGE'])){require_once __DIR__.'/inline.php';inline_form_result($data,$status);}
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    exit;
}
function input(): array {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        header('Allow: POST'); respond(['error'=>'Bitte das Formular verwenden. / Please use the form.'],405);
    }
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $originHost = strtolower((string)parse_url($origin, PHP_URL_HOST));
    $host = strtolower(explode(':', $_SERVER['HTTP_HOST'] ?? '')[0]);
    if (($origin !== '' && $originHost !== $host) || ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '') === 'cross-site') respond(['error'=>'Ungültige Herkunft. / Invalid origin.'],403);
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0)>32768) respond(['error'=>'Anfrage zu groß. / Request too large.'],413);
    $raw=file_get_contents('php://input',false,null,0,32769);
    if ($raw===false || strlen($raw)>32768) respond(['error'=>'Anfrage zu groß. / Request too large.'],413);
    if (str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json')) {
        $parsed=json_decode($raw,true,16,JSON_THROW_ON_ERROR);
        if (!is_array($parsed) || array_is_list($parsed)) respond(['error'=>'Ungültige Anfrage. / Invalid request.'],400);
        return $parsed;
    }
    return $_POST;
}
function clean(mixed $value, int $max): string {
    if(!is_string($value)||!preg_match('//u',$value))return '';
    $value=trim(str_replace("\r",'', $value));
    $value=preg_replace('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/u','',$value);
    return preg_match_all('/./us',$value)<=$max ? $value : '';
}
function private_directory(string $part): string {
    $root=realpath($_SERVER['DOCUMENT_ROOT'] ?? '');
    if(!$root)throw new RuntimeException('Storage root unavailable');
    $name=match($part){'anfragen'=>'anfragen',default=>throw new RuntimeException('Invalid storage target')};
    $path=$root.'/'.$name;
    if(is_link($path))throw new RuntimeException('Invalid storage path');
    if(!is_dir($path)&&!mkdir($path,0700)&&!is_dir($path))throw new RuntimeException('Storage unavailable');
    if(!chmod($path,0700))throw new RuntimeException('Storage permissions unavailable');
    $deny="Require all denied\n";
    if(!is_file($path.'/.htaccess') || file_get_contents($path.'/.htaccess')!==$deny)atomic_write($path.'/.htaccess',$deny);
    return $path;
}
function atomic_write(string $file,string $text): void {
    $tmp=$file.'.'.bin2hex(random_bytes(6)).'.tmp';
    try{
        if(file_put_contents($tmp,$text,LOCK_EX)!==strlen($text))throw new RuntimeException('Write failed');
        if(!chmod($tmp,0600))throw new RuntimeException('File permissions unavailable');
        if(!rename($tmp,$file))throw new RuntimeException('Commit failed');
    }finally{if(is_file($tmp))unlink($tmp);}
}
function rate_limit(string $directory,int $limit): void {
    $file=$directory.'/.rate.json';$lock=fopen($directory.'/.rate.lock','c+');
    if(!$lock||!flock($lock,LOCK_EX))throw new RuntimeException('Lock unavailable');
    try{
        if(!is_file($directory.'/.salt'))atomic_write($directory.'/.salt',bin2hex(random_bytes(32)));
        $ip=hash_hmac('sha256',$_SERVER['REMOTE_ADDR']??'unknown',file_get_contents($directory.'/.salt'));
        $hour=(int)floor(time()/3600);$data=is_file($file)?json_decode(file_get_contents($file),true):null;
        if(!is_array($data)||($data['hour']??0)!==$hour)$data=['hour'=>$hour,'counts'=>[]];
        if(($data['counts'][$ip]??0)>=$limit || count($data['counts'])>10000){header('Retry-After: 3600');respond(['error'=>'Bitte später erneut versuchen. / Please try again later.'],429);}
        $data['counts'][$ip]=($data['counts'][$ip]??0)+1;atomic_write($file,json_encode($data,JSON_THROW_ON_ERROR));
    }finally{flock($lock,LOCK_UN);fclose($lock);}
}

function request_uuid(): string {
    $b=random_bytes(16);$b[6]=chr((ord($b[6])&15)|64);$b[8]=chr((ord($b[8])&63)|128);$h=bin2hex($b);
    return substr($h,0,8).'-'.substr($h,8,4).'-'.substr($h,12,4).'-'.substr($h,16,4).'-'.substr($h,20);
}
