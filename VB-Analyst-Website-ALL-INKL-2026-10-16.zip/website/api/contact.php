<?php
declare(strict_types=1);
require_once __DIR__.'/bootstrap.php';
try {
    $data=input(); $GLOBALS['VB_FORM_INPUT']=$data;
    $en=($data['language']??'')==='en';
    $invalid=$en?'Please complete the required fields and acknowledge the privacy notice.':'Bitte füllen Sie die Pflichtfelder aus und bestätigen Sie die Datenschutzhinweise.';
    if (!empty($data['website'])) respond(['error'=>$invalid],400);
    $record=[];
    foreach (['name'=>150,'company'=>200,'email'=>250,'task'=>4000,'engagement'=>20,'field'=>30,'timing'=>20,'workplace'=>20] as $key=>$max) {
        $record[$key]=clean($data[$key]??'',$max);
        if ($key!=='task') $record[$key]=str_replace(["\n","\t"],' ',$record[$key]);
        // Optional fields must not silently disappear if an oversized value is supplied.
        if (isset($data[$key]) && (!is_string($data[$key]) || (trim($data[$key])!=='' && $record[$key]===''))) respond(['error'=>$invalid],400);
    }
    $record['language']=$en?'en':'de';
    if ($record['name']==='' || !filter_var($record['email'],FILTER_VALIDATE_EMAIL) || preg_match_all('/./us',$record['task'])<15 || ($data['privacy']??'')!=='acknowledged') respond(['error'=>$invalid],400);
    $fields=json_decode(file_get_contents(__DIR__.'/fields.json'),true,16,JSON_THROW_ON_ERROR);
    $allowed=['engagement'=>['expert','permanent','service','white','talent','open','team'],'field'=>array_keys($fields),'timing'=>['open','asap','months','later'],'workplace'=>['open','remote','hybrid','onsite']];
    foreach ($allowed as $key=>$values) if(!in_array($record[$key],$values,true)) respond(['error'=>$invalid],400);
    $id=clean($data['request_id']??'',40);
    if ($id==='') $id=request_uuid();
    if (!preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/iD',$id)) respond(['error'=>$invalid],400);
    $id=strtolower($id); $directory=private_directory('anfragen');
    $lock=fopen($directory.'/.requests.lock','c+');
    if(!$lock||!flock($lock,LOCK_EX)) throw new RuntimeException('Lock unavailable');
    try {
        $hash=hash('sha256',json_encode($record,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
        $file=$directory.'/anfrage-'.$id.'.txt';
        if (is_file($file)) {
            $handle=fopen($file,'r'); if(!$handle) throw new RuntimeException('Read unavailable');
            $first=trim((string)fgets($handle)); fclose($handle);
            if(!hash_equals('Pruefsumme: '.$hash,$first)) respond(['error'=>$en?'The enquiry has changed. Please send it again to create a new reference.':'Die Anfrage wurde geändert. Bitte senden Sie sie erneut, um eine neue Referenz anzulegen.'],409);
        } else {
            rate_limit($directory,20);
            $models=['expert'=>'Experten für ein Projekt','permanent'=>'Personalvermittlung / Festanstellung','service'=>'Managed Service','white'=>'White Label','talent'=>'Als Experte mitarbeiten','open'=>'Noch offen','team'=>'Expertenteam'];
            $timing=['open'=>'Noch offen','asap'=>'So bald wie möglich','months'=>'Innerhalb von 1–3 Monaten','later'=>'Später / langfristig'];
            $work=['open'=>'Noch offen','remote'=>'Remote','hybrid'=>'Hybrid','onsite'=>'Vor Ort'];
            $text=implode("\n",['Pruefsumme: '.$hash,'VB ANALYST – KONTAKTANFRAGE','Referenz: '.$id,'Eingang (UTC): '.gmdate('Y-m-d H:i:s'),'Kontakt: info@vb-analyst.de','','Name: '.$record['name'],'Unternehmen: '.$record['company'],'E-Mail: '.$record['email'],'Zusammenarbeit: '.$models[$record['engagement']],'Fachbereich: '.$fields[$record['field']],'Gewünschter Start: '.$timing[$record['timing']],'Arbeitsmodell: '.$work[$record['workplace']],'Sprache: '.$record['language'],'','AUFGABE UND GEWÜNSCHTES ERGEBNIS',$record['task'],'','Datenschutzhinweise bestätigt: Ja','']);
            atomic_write($file,$text);
        }
    } finally {flock($lock,LOCK_UN);fclose($lock);}
    setcookie('vb_receipt',$id,['expires'=>time()+1800,'path'=>'/','secure'=>true,'httponly'=>true,'samesite'=>'Strict']);
    if(isset($GLOBALS['VB_INLINE_PAGE'])){header('Location: '.($en?'/en/danke/':'/danke/'),true,303);exit;}
    respond(['saved'=>true,'reference'=>$id]);
} catch (JsonException $error) {
    respond(['error'=>'Ungültige Anfrage. / Invalid request.'],400);
} catch (Throwable $error) {
    error_log('VB Analyst contact: '.$error->getMessage());
    respond(['error'=>'Die Anfrage konnte nicht übermittelt werden. Ihre Eingaben bleiben erhalten. Bitte versuchen Sie es erneut oder kontaktieren Sie info@vb-analyst.de. / Your enquiry could not be submitted. Please try again or contact info@vb-analyst.de.'],503);
}
