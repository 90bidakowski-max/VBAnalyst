<?php
declare(strict_types=1);
require_once __DIR__.'/bootstrap.php';
$page=$GLOBALS['VB_PAGE']??'';
if(!in_array($page,['/kontakt/','/en/kontakt/'],true)){http_response_code(404);exit;}
$GLOBALS['VB_INLINE_PAGE']=$page;
$method=$_SERVER['REQUEST_METHOD']??'GET';
if($method==='POST'){require __DIR__.'/contact.php';exit;}
if(!in_array($method,['GET','HEAD'],true)){header('Allow: GET, HEAD, POST');http_response_code(405);exit;}
header_remove('X-Robots-Tag');
header('Content-Type: text/html; charset=utf-8');
if($method==='HEAD')exit;
$en=str_starts_with($page,'/en/');
$values=[];
$fields=json_decode(file_get_contents(__DIR__.'/fields.json'),true);
$field=clean($_GET['bereich']??'',30);if(isset($fields[$field]))$values['field']=$field;
$model=clean($_GET['modell']??'',20);if(in_array($model,['expert','permanent','service','white','talent','open','team'],true))$values['engagement']=$model;
$timing=clean($_GET['start']??'',20);if(in_array($timing,['open','asap','months','later'],true))$values['timing']=$timing;
$place=clean($_GET['arbeitsort']??'',20);if(in_array($place,['open','remote','hybrid','onsite'],true))$values['workplace']=$place;
$subject=clean($_GET['thema']??'',200);$brief=clean($_GET['briefing']??'',2400);
$task=$subject!==''?($en?'I need support with: ':'Ich benötige Unterstützung bei: ').$subject."\n":'';
if($brief!=='')$task.=($task!==''?"\n":'').$brief;
$selected=clean($_GET['auswahl']??'',6000);
if($selected!==''){
    $choices=json_decode(file_get_contents(__DIR__.'/choices.json'),true);
    $titles=[];
    foreach(array_slice(array_unique(explode(',',$selected)),0,40) as $id)if(isset($choices[$id]))$titles[]='• '.$choices[$id][$en?'en':'de'];
    if($titles)$task.="\n\n".($en?'My shortlisted expertise:':'Meine vorgemerkte Expertise:')."\n".implode("\n",$titles);
}
// Limit by Unicode characters without requiring mbstring.
preg_match('/^.{0,4000}/us',$task,$limited);$values['task']=$limited[0]??'';
require_once __DIR__.'/inline.php';
render_contact($values);
