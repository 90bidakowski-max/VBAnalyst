<?php
$GLOBALS['VB_LANGUAGE']='de';
require dirname(__DIR__,1).'/api/thanks.php';
